document.getElementById('scores').innerHTML = 'suck it bitch';
alert('die');
