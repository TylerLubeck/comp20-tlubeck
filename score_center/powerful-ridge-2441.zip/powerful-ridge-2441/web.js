var express = require('express');
var dbURL = process.env.MONGOLAB_URI ||
            process.env.MONGOHQ_URL ||
            'mongodb://localhost/mydb';

var collections = ["games", "reports"];

var db = require('mongojs').connect(dbURL, collections);
var app = express();


app.use('/css', express.static(__dirname + '/css'));
//app.use(express.static(__dirname + '/html'));
app.use('/js', express.static(__dirname + '/js'));


app.all('/', function(req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");
        next();
        });

app.get('/', function(request, response) {    
        var text = '<table border="1">';
        var allGames = new Array();
        db.games.find({}, function(err, games) {
            games.forEach(function(game) {
                text += '<tr><td>' + game.game_title + '</td>';
                text += '<td>' + game.username + '</td>';
                text += '<td>' + game.score + '</td>';
                text += '<td>' + game.created_at + '</td></tr>';
                console.log(game);
                }); 

            console.log('DOOOOOOOOOONE');
            text += '</table>';
            console.log(text);
            response.send(text);
            });
        });

app.post('/submit.json', function(request, response) {
        gameName = request.query.game_title;
        userName = request.query.username;
        scoreVal = parseInt(request.query.score);

        if(gameName == undefined || userName == undefined || 
            scoreVal == undefined || scoreVal == 'NaN') {
        
            response.send({'error':{'game_title':gameName, 
                            'username':userName, 'score':scoreVal}});
        }

        d = new Date();


        db.games.insert({'game_title':gameName, 'username':userName, 
            'score':scoreVal, 'created_at':d.toString()});
});

app.get('/submit.json', function(request, response) {
        gameName = request.query.game_title;
        userName = request.query.username;
        scoreVal = parseInt(request.query.score);
        console.log(scoreVal);
        if(gameName == undefined || userName == undefined || 
            scoreVal == undefined || scoreVal == 'NaN') {
            response.send({'error':{'game_title':gameName, 
                            'username':userName, 'score':scoreVal}});
            return;
        }

        d = new Date();

        db.games.insert({'game_title':gameName, 'username':userName, 
            'score':scoreVal, 'created_at':d.toString()});
    
        response.send('done');
});    



app.get('/highscores.json', function(request, response) {
        gameTitle = request.query.game_title;
        if(gameTitle == undefined) {
        response.send({'error':{'game_title':gameTitle}}); 
        return;   
        }

        console.log('Game title: ' + gameTitle);
        var gameInfo = new Array();

        db.games.find({'game_title': gameTitle}).sort({'score':1} , 
            function(err, games) {
                if(err || !games) {
                    if(err) {
                        response.send('error! - ' + err);
                        return;
                    }
                    response.send('blank');
                    return;
                } else {
                    var i = 0;
                    games.forEach(function(game) {
                        if(i < 10) {        
                            gameInfo.push(game);
                            i++;
                        }
                    });
                    response.send(JSON.stringify(gameInfo));
                    return;
                }
            });
});

app.get('/usersearch', function(request, response) {
   
   response.sendfile('html/usersearch.html');

});

app.get('/search', function(request, response) {
    db.games.find({'username':request.query.UN}, function(err, games) {
        if(err) {
            response.send({'games':null, 'exists':true, 'error':true});
            return;
        }
        if(!games) {
            response.send({'games':null, 'exists':false, 'error':true});
            return;
        }

        var array = new Array();
        games.forEach(function(game) {
            array.push(game);
        });
        console.log(array); 
        response.send(JSON.stringify(array));
    });
});


var port = process.env.PORT || 5000;
app.listen(port, function() {
        console.log("Listening on " + port);
});



